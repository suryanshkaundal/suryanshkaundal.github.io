import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import BlackholeBackground from "./components/BlackholeBackground";
import Navigation from "./components/Navigation";
import { AudioProvider } from "./components/AudioManager";
import Gate from "./pages/Gate";
import Overview from "./pages/Overview";
import Projects from "./pages/Projects";
import Arcade from "./pages/Arcade";
import Gadgets from "./pages/Gadgets";

function RouteShell() {
  const location = useLocation();
  const onGate = location.pathname === "/";
  return (
    <>
      {!onGate && <Navigation />}
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Gate />} />
          <Route path="/overview" element={<Overview />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/arcade" element={<Arcade />} />
          <Route path="/gadgets" element={<Gadgets />} />
          <Route path="*" element={<Overview />} />
        </Routes>
      </AnimatePresence>

      {/* persistent footer — only on main pages */}
      {!onGate && (
        <footer className="relative z-10 border-t border-white/5 mt-8">
          <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <p className="font-display text-lg text-amber-50 tracking-[0.2em]">ENTERING MY UNIVERSE</p>
              <p className="font-mono text-[0.7rem] text-white/50 tracking-[0.3em] mt-1">SURYANSH · PERSONAL PORTFOLIO · BUILT WITH REACT</p>
            </div>
            <div className="flex flex-col md:items-end gap-1">
              <p className="font-mono text-[0.7rem] text-white/50 tracking-[0.3em]">TRANSMISSION · STILL IN ORBIT</p>
              <p className="text-xs text-white/40">© {new Date().getFullYear()} · All rights reserved.</p>
            </div>
          </div>
        </footer>
      )}
    </>
  );
}

export default function App() {
  return (
    <AudioProvider>
      <div className="relative min-h-screen text-white">
        <BlackholeBackground />
        <div className="vignette" />
        <RouteShell />
      </div>
    </AudioProvider>
  );
}
