import { useEffect, useRef } from "react";

// Cinematic, slow-spinning 3D black hole.
// Uses layered conic gradients + transforms to simulate an accretion disc,
// plus a generated starfield canvas for parallax depth.
export default function BlackholeBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0, h = 0;
    const resize = () => {
      w = canvas.width = window.innerWidth * window.devicePixelRatio;
      h = canvas.height = window.innerHeight * window.devicePixelRatio;
      canvas.style.width = window.innerWidth + "px";
      canvas.style.height = window.innerHeight + "px";
    };
    resize();
    window.addEventListener("resize", resize);

    type Star = { x: number; y: number; z: number; s: number; tw: number };
    const makeStars = (n: number): Star[] =>
      Array.from({ length: n }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        z: Math.random() * 0.8 + 0.2,
        s: Math.random() * 1.3 + 0.2,
        tw: Math.random() * Math.PI * 2,
      }));

    let stars = makeStars(320);
    window.addEventListener("resize", () => (stars = makeStars(320)));

    let raf = 0;
    let t0 = performance.now();

    const draw = (now: number) => {
      const dt = (now - t0) / 1000;
      t0 = now;
      ctx.clearRect(0, 0, w, h);

      // subtle nebula wash
      const grad = ctx.createRadialGradient(w * 0.3, h * 0.35, 0, w * 0.3, h * 0.35, Math.max(w, h) * 0.8);
      grad.addColorStop(0, "rgba(120,80,180,0.05)");
      grad.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // stars
      for (const s of stars) {
        s.tw += dt * 2;
        const a = 0.5 + Math.sin(s.tw) * 0.45;
        const size = s.s * window.devicePixelRatio * s.z;
        ctx.globalAlpha = Math.max(0.2, Math.min(1, a * s.z));
        ctx.fillStyle = s.z > 0.7 ? "rgba(255,235,200,1)" : "rgba(220,230,255,1)";
        ctx.beginPath();
        ctx.arc(s.x, s.y, size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div className="blackhole-wrap" aria-hidden="true">
      <canvas ref={canvasRef} style={{ position: "absolute", inset: 0, zIndex: 1 }} />
      <div className="stars" />
      <div className="stars-2" />
      <div className="stars-3" />

      <div className="blackhole-stage">
        <div className="disc disc-2" />
        <div className="disc" />
        <div className="ring-photosphere" />
        <div className="void" />
      </div>
    </div>
  );
}
