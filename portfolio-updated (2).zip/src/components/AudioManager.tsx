import { createContext, useContext, useEffect, useRef, useState } from "react";

type AudioCtx = {
  play: () => void;
  pause: () => void;
  toggle: () => void;
  playing: boolean;
  volume: number;
  setVolume: (v: number) => void;
};

const Ctx = createContext<AudioCtx | null>(null);

export function AudioProvider({ children }: { children: React.ReactNode }) {
  const ctxRef = useRef<AudioContext | null>(null);
  const masterRef = useRef<GainNode | null>(null);
  const padRef = useRef<{ stop: () => void } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.35);

  const ensureCtx = () => {
    if (!ctxRef.current) {
      const AC: typeof AudioContext =
        (window as unknown as { AudioContext: typeof AudioContext; webkitAudioContext?: typeof AudioContext }).AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      const master = ctx.createGain();
      master.gain.value = volume;
      master.connect(ctx.destination);
      ctxRef.current = ctx;
      masterRef.current = master;
    }
    return ctxRef.current!;
  };

  // Ambient cosmic pad — built procedurally (no external assets required).
  const startPad = () => {
    const ctx = ensureCtx();
    if (padRef.current) return;
    const master = masterRef.current!;

    const now = ctx.currentTime;
    const durations = [8.0, 10.2, 12.4];
    const freqs = [55, 82.4, 110, 164.8]; // A1, E2, A2, E3
    const nodes: { stop: () => void }[] = [];

    // slow oscillators with detune
    freqs.slice(0, 3).forEach((f, i) => {
      const o = ctx.createOscillator();
      o.type = i === 0 ? "sine" : "triangle";
      o.frequency.value = f;
      o.detune.value = (Math.random() - 0.5) * 12;

      const g = ctx.createGain();
      g.gain.value = 0;
      g.gain.linearRampToValueAtTime(0.08 / (i + 1), now + 4 + i);

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 650 + i * 80;
      filter.Q.value = 0.8;

      // slow lfo on filter
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.04 + i * 0.02;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 220;
      lfo.connect(lfoGain).connect(filter.frequency);

      o.connect(filter).connect(g).connect(master);
      o.start(now);
      lfo.start(now);
      nodes.push({
        stop: () => {
          try {
            g.gain.cancelScheduledValues(ctx.currentTime);
            g.gain.linearRampToValueAtTime(0, ctx.currentTime + 2);
            o.stop(ctx.currentTime + 2.2);
            lfo.stop(ctx.currentTime + 2.2);
          } catch {}
        },
      });
    });

    // shimmer — short reverb-ish delayed pulses
    const startShimmer = () => {
      const o = ctx.createOscillator();
      o.type = "sine";
      const baseFreq = freqs[3];
      o.frequency.value = baseFreq * 2;

      const g = ctx.createGain();
      g.gain.value = 0;

      const delay = ctx.createDelay(1.5);
      delay.delayTime.value = 0.45;
      const fb = ctx.createGain();
      fb.gain.value = 0.35;

      o.connect(g);
      g.connect(master);
      g.connect(delay);
      delay.connect(fb);
      fb.connect(delay);
      delay.connect(master);

      o.start();
      let t = ctx.currentTime + 3;
      const schedule = () => {
        if (!ctxRef.current) return;
        const c = ctxRef.current!;
        const pitch = baseFreq * [1.5, 2, 2.5, 3][Math.floor(Math.random() * 4)];
        o.frequency.setValueAtTime(pitch, t);
        g.gain.cancelScheduledValues(t);
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(0.04, t + 0.05);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 2.5);
        t += 4 + Math.random() * 3;
        setTimeout(schedule, (t - c.currentTime) * 1000 - 100);
      };
      schedule();

      nodes.push({
        stop: () => {
          try {
            o.stop(ctx.currentTime + 3);
          } catch {}
        },
      });
    };
    startShimmer();

    padRef.current = {
      stop: () => {
        nodes.forEach((n) => n.stop());
        padRef.current = null;
      },
    };
    // avoid unused warning
    void durations;
  };

  const play = () => {
    setPlaying(true);
    startPad();
    const ctx = ensureCtx();
    if (ctx.state === "suspended") ctx.resume();
  };
  const pause = () => {
    setPlaying(false);
    padRef.current?.stop();
  };
  const toggle = () => (playing ? pause() : play());

  useEffect(() => {
    if (masterRef.current) masterRef.current.gain.value = volume;
  }, [volume]);

  useEffect(() => {
    return () => padRef.current?.stop();
  }, []);

  return <Ctx.Provider value={{ play, pause, toggle, playing, volume, setVolume }}>{children}</Ctx.Provider>;
}

export function useAudio() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAudio must be used inside AudioProvider");
  return c;
}
