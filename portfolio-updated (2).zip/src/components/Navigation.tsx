import { NavLink } from "react-router-dom";
import { useAudio } from "./AudioManager";

const links = [
  { to: "/overview", label: "Overview", idx: "01" },
  { to: "/projects", label: "Projects", idx: "02" },
  { to: "/arcade", label: "Arcade", idx: "03" },
  { to: "/gadgets", label: "Gadgets", idx: "04" },
];

export default function Navigation() {
  const { toggle, playing } = useAudio();
  return (
    <header className="fixed top-0 left-0 right-0 z-30">
      <div className="mx-auto max-w-7xl px-5 md:px-10 py-5 flex items-center justify-between">
        <NavLink to="/" className="flex items-center gap-3 group">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-amber-300/30 bg-amber-400/5 group-hover:border-amber-300/70 transition">
            <span className="h-2.5 w-2.5 rounded-full bg-gradient-to-br from-amber-200 to-orange-500 shadow-[0_0_12px_rgba(255,179,71,0.8)]" />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="font-display text-[0.95rem] text-amber-100/90 tracking-[0.28em] font-bold">ENTERING MY UNIVERSE</span>
            <span className="font-mono text-[0.65rem] text-white/50 tracking-[0.35em] font-semibold">SURYANSH · PORTFOLIO v1.0</span>
          </span>
        </NavLink>

        <nav className="hidden md:flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md px-2 py-1.5">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `px-4 py-1.5 text-[0.72rem] tracking-[0.22em] uppercase rounded-full transition ${
                  isActive
                    ? "bg-gradient-to-r from-amber-300/20 to-orange-500/20 text-amber-100 border border-amber-300/30"
                    : "text-white/60 hover:text-amber-100"
                }`
              }
            >
              <span className="mr-2 text-white/30 font-mono">{l.idx}</span>
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={toggle}
            className="btn-ghost !py-1.5 !px-3 text-[0.7rem]"
            title={playing ? "Mute soundtrack" : "Play soundtrack"}
          >
            <span className={`inline-block h-1.5 w-1.5 rounded-full ${playing ? "bg-amber-300 shadow-[0_0_8px_rgba(255,179,71,0.9)] animate-pulse" : "bg-white/30"}`} />
            {playing ? "AUDIO · ON" : "AUDIO · OFF"}
          </button>
        </div>
      </div>

      {/* mobile nav */}
      <nav className="md:hidden mx-5 mb-4 flex items-center gap-1 overflow-x-auto rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md px-2 py-1.5">
        {links.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            className={({ isActive }) =>
              `whitespace-nowrap px-3 py-1.5 text-[0.68rem] tracking-[0.2em] uppercase rounded-full transition ${
                isActive ? "bg-amber-300/15 text-amber-100 border border-amber-300/30" : "text-white/60"
              }`
            }
          >
            <span className="mr-1 text-white/30 font-mono">{l.idx}</span>
            {l.label}
          </NavLink>
        ))}
      </nav>
    </header>
  );
}
