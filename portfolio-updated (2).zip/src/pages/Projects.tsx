import { motion } from "framer-motion";

const projects = [
  {
    code: "PROJ · 01",
    title: "TechKindness",
    tagline: "A social initiative, engineered.",
    summary:
      "An NGO-style platform leveraging technology to connect volunteers, mentors, and educators with students across underserved communities. Built as a responsive web hub with program listings, impact stories, and donation signposting.",
    link: "https://techkindness.netlify.app",
    accent: "#ffb347",
    icon: "◈",
    stack: ["React", "Vite", "Tailwind", "Netlify"],
    xp: 620,
  },
  {
    code: "PROJ · 02",
    title: "Cosmic Webb",
    tagline: "A professional web development agency.",
    summary:
      "Branding, portfolio, and marketing websites for small businesses and creators. Each build is designed around a cinematic brief — strong typography, considered motion, and conversion-led layouts.",
    link: "https://cosmic-webb.netlify.app",
    accent: "#7ce2ff",
    icon: "✶",
    stack: ["Next.js", "Tailwind", "Framer Motion"],
    xp: 700,
  },
  {
    code: "PROJ · 03",
    title: "Study DarkForge",
    tagline: "Advanced build & productivity tracker.",
    summary:
      "A dark, studio-grade environment for planning long study arcs, tracking sessions, and visualising momentum over weeks. Built for students who treat preparation like a craft.",
    link: "https://study-darkforge.netlify.app",
    accent: "#b794f4",
    icon: "✦",
    stack: ["React", "Zustand", "Tailwind"],
    xp: 580,
  },
  {
    code: "PROJ · 04",
    title: "StudyKaroo",
    tagline: "Syllabus & progress tracker for Class 10.",
    summary:
      "Topic-wise syllabus tracker, day-by-day planning, and revision maps aligned with the Class 10 curriculum. Designed to remove friction between intent and execution.",
    link: "https://studykaroo.netlify.app",
    accent: "#ffd27a",
    icon: "✧",
    stack: ["React", "Tailwind", "LocalStorage"],
    xp: 520,
  },
];

export default function Projects() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="relative z-10 pt-36 pb-24 px-6"
    >
      <div className="mx-auto max-w-7xl">
        <div>
          <p className="font-mono text-[0.7rem] tracking-[0.5em] text-amber-200/70">CHAPTER II · PAGE 02</p>
          <h2 className="font-display text-4xl md:text-6xl text-amber-50 mt-3 glow-text font-bold">The Project Nebula</h2>
          <p className="text-white/70 mt-3 max-w-2xl font-medium">
            Four active constellations in the public orbit. Each project is live, maintained, and serving real users — from community platforms to personal productivity tools.
          </p>
        </div>

        <div className="divider-line my-10" />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
          {projects.map((p, i) => (
            <motion.article
              key={p.code}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
              className="glass rounded-3xl p-7 relative overflow-hidden group"
              style={{ borderColor: `${p.accent}22` }}
            >
              {/* accent glow */}
              <div
                className="pointer-events-none absolute -top-20 -right-20 h-60 w-60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                style={{ background: `radial-gradient(closest-side, ${p.accent}55, transparent)`, filter: "blur(30px)" }}
              />
              <div className="relative">
                <div className="flex items-start justify-between">
                  <span className="chip">{p.code}</span>
                  <div className="flex items-center gap-2">
                    <div
                      className="h-11 w-11 rounded-2xl flex items-center justify-center text-xl font-display"
                      style={{ background: `${p.accent}15`, border: `1px solid ${p.accent}55`, color: p.accent }}
                    >
                      {p.icon}
                    </div>
                  </div>
                </div>

              <h3 className="font-display text-2xl sm:text-3xl mt-5 text-amber-50 font-bold">{p.title}</h3>
              <p className="text-sm mt-1 tracking-wide font-semibold" style={{ color: p.accent }}>{p.tagline}</p>

              <p className="text-sm text-white/70 mt-4 leading-relaxed font-medium">{p.summary}</p>

                <div className="mt-5 flex flex-wrap gap-2">
                  {p.stack.map((s) => (
                    <span key={s} className="chip !text-[0.62rem]">{s}</span>
                  ))}
                </div>

                <div className="mt-7 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-32 xp-track h-2">
                      <div className="xp-fill" style={{ width: `${Math.min(100, (p.xp / 900) * 100)}%`, background: p.accent }} />
                    </div>
                    <span className="font-mono text-[0.7rem] text-white/60">+{p.xp} XP</span>
                  </div>
                  <a
                    href={p.link}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-primary !py-2 !px-4 !text-[0.7rem]"
                    style={{ background: `linear-gradient(135deg, ${p.accent}ee, ${p.accent}88)`, color: "#120a00" }}
                  >
                    LAUNCH →
                  </a>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {/* CTA strip */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="mt-16 glass rounded-3xl p-10 md:p-14 text-center relative overflow-hidden"
        >
          <div className="pointer-events-none absolute -left-20 -top-20 h-80 w-80 rounded-full opacity-40"
            style={{ background: "radial-gradient(closest-side, rgba(255,179,71,0.5), transparent)", filter: "blur(40px)" }} />
          <p className="font-mono text-[0.7rem] tracking-[0.5em] text-amber-200/70">SIGNAL · OPEN</p>
          <h3 className="font-display text-3xl md:text-5xl text-amber-50 mt-3">More constellations under construction.</h3>
          <p className="text-white/60 mt-4 max-w-2xl mx-auto">
            New projects, experiments, and case studies are being plotted. Follow the trajectory through the wormhole arcade, or return to the overview for the full flight log.
          </p>
        </motion.div>
      </div>
    </motion.section>
  );
}
