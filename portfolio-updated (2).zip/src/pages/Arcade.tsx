import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

/* ============ Game 1: Space Evader ============ */
function SpaceEvader() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stateRef = useRef({
    running: false,
    ship: { x: 0, y: 0, w: 32, h: 22, vx: 0, vy: 0 },
    asteroids: [] as { x: number; y: number; r: number; vx: number; vy: number; rot: number; vr: number }[],
    keys: {} as Record<string, boolean>,
    score: 0,
    best: Number(localStorage.getItem("evader:best") || 0),
    t: 0,
    lives: 3,
    over: false,
  });
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [best, setBest] = useState(stateRef.current.best);
  const [running, setRunning] = useState(false);
  const [over, setOver] = useState(false);

  const start = () => {
    const s = stateRef.current;
    const canvas = canvasRef.current!;
    s.ship.x = canvas.width / 2;
    s.ship.y = canvas.height - 80;
    s.asteroids = [];
    s.score = 0;
    s.lives = 3;
    s.t = 0;
    s.over = false;
    s.running = true;
    setOver(false);
    setRunning(true);
    setLives(3);
    setScore(0);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const resize = () => {
      const parent = canvas.parentElement!;
      canvas.width = parent.clientWidth;
      canvas.height = Math.max(360, parent.clientHeight || 460);
    };
    resize();
    window.addEventListener("resize", resize);

    const onKey = (e: KeyboardEvent, down: boolean) => {
      const s = stateRef.current;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " ", "w", "a", "s", "d", "W", "A", "S", "D"].includes(e.key)) e.preventDefault();
      s.keys[e.key.toLowerCase()] = down;
    };
    const kd = (e: KeyboardEvent) => onKey(e, true);
    const ku = (e: KeyboardEvent) => onKey(e, false);
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);

    // pointer controls for touch / mouse
    let pointerActive = false;
    const onPointer = (e: PointerEvent) => {
      const s = stateRef.current;
      const rect = canvas.getBoundingClientRect();
      const x = (e.clientX - rect.left) * (canvas.width / rect.width);
      const y = (e.clientY - rect.top) * (canvas.height / rect.height);
      s.ship.x = x;
      s.ship.y = y;
      pointerActive = true;
    };
    canvas.addEventListener("pointerdown", onPointer);
    canvas.addEventListener("pointermove", (e) => pointerActive && onPointer(e));
    canvas.addEventListener("pointerup", () => (pointerActive = false));

    let raf = 0;
    const loop = () => {
      const s = stateRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      // bg
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, "#07080f");
      g.addColorStop(1, "#0a0500");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);

      // parallax stars
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      for (let i = 0; i < 80; i++) {
        const x = (i * 97 + (stateRef.current.t * (i % 3 === 0 ? 40 : 20))) % W;
        const y = (i * 53) % H;
        ctx.globalAlpha = 0.3 + ((i * 31) % 100) / 200;
        ctx.fillRect(x, y, 1.2, 1.2);
      }
      ctx.globalAlpha = 1;

      if (s.running) {
        s.t += 1 / 60;

        // ship movement
        const speed = 6;
        if (s.keys["arrowleft"] || s.keys["a"]) s.ship.x -= speed;
        if (s.keys["arrowright"] || s.keys["d"]) s.ship.x += speed;
        if (s.keys["arrowup"] || s.keys["w"]) s.ship.y -= speed;
        if (s.keys["arrowdown"] || s.keys["s"]) s.ship.y += speed;
        s.ship.x = Math.max(20, Math.min(W - 20, s.ship.x));
        s.ship.y = Math.max(20, Math.min(H - 20, s.ship.y));

        // spawn asteroids — ramp up over time
        const spawnRate = 0.02 + Math.min(0.05, s.t * 0.002);
        if (Math.random() < spawnRate) {
          const r = 12 + Math.random() * 26;
          s.asteroids.push({
            x: Math.random() * W,
            y: -r - 10,
            r,
            vx: (Math.random() - 0.5) * 1.8,
            vy: 1.4 + Math.random() * 2 + s.t * 0.04,
            rot: Math.random() * Math.PI * 2,
            vr: (Math.random() - 0.5) * 0.05,
          });
        }

        // update & draw asteroids
        for (let i = s.asteroids.length - 1; i >= 0; i--) {
          const a = s.asteroids[i];
          a.x += a.vx;
          a.y += a.vy;
          a.rot += a.vr;
          if (a.y - a.r > H + 40) {
            s.asteroids.splice(i, 1);
            s.score += 10;
            continue;
          }
          // draw
          ctx.save();
          ctx.translate(a.x, a.y);
          ctx.rotate(a.rot);
          ctx.fillStyle = "#6b5a48";
          ctx.strokeStyle = "rgba(255,180,100,0.4)";
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          const pts = 9;
          for (let p = 0; p < pts; p++) {
            const ang = (p / pts) * Math.PI * 2;
            const rr = a.r * (0.78 + ((p * 37) % 30) / 100);
            const px = Math.cos(ang) * rr;
            const py = Math.sin(ang) * rr;
            if (p === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.restore();

          // collision (circle vs point-ish)
          const dx = a.x - s.ship.x;
          const dy = a.y - s.ship.y;
          const d = Math.hypot(dx, dy);
          if (d < a.r + 14) {
            s.asteroids.splice(i, 1);
            s.lives -= 1;
            setLives(s.lives);
            if (s.lives <= 0) {
              s.running = false;
              s.over = true;
              setOver(true);
              setRunning(false);
              if (s.score > s.best) {
                s.best = s.score;
                setBest(s.score);
                localStorage.setItem("evader:best", String(s.score));
              }
            }
          }
        }

        // draw ship
        ctx.save();
        ctx.translate(s.ship.x, s.ship.y);
        // thruster
        ctx.fillStyle = "rgba(255,179,71,0.8)";
        ctx.beginPath();
        ctx.moveTo(-8, 10);
        ctx.lineTo(0, 22 + Math.sin(s.t * 20) * 4);
        ctx.lineTo(8, 10);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = "#e9ecf5";
        ctx.strokeStyle = "rgba(255,180,100,0.7)";
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(0, -16);
        ctx.lineTo(14, 12);
        ctx.lineTo(0, 6);
        ctx.lineTo(-14, 12);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();

        s.score += 1;
        setScore(Math.floor(s.score / 2));
      } else {
        // idle ship
        ctx.save();
        ctx.translate(W / 2, H - 100);
        ctx.fillStyle = "#e9ecf5";
        ctx.beginPath();
        ctx.moveTo(0, -16);
        ctx.lineTo(14, 12);
        ctx.lineTo(0, 6);
        ctx.lineTo(-14, 12);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
    };
  }, []);

  return (
    <div className="glass rounded-3xl p-6 md:p-8 relative overflow-hidden">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <span className="chip">ARCADE · 01</span>
          <h3 className="font-display text-2xl md:text-3xl text-amber-50 mt-3 font-bold">Space Evader</h3>
          <p className="text-sm text-white/70 mt-2 max-w-xl font-medium">Dodge the asteroid field. Survive as long as possible — difficulty scales with time. Arrow keys / WASD or tap-drag on mobile.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">SCORE</p>
            <p className="font-display text-xl text-amber-200">{score}</p>
          </div>
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">BEST</p>
            <p className="font-display text-xl text-amber-200">{best}</p>
          </div>
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">LIVES</p>
            <p className="font-display text-xl text-amber-200">{"♥".repeat(Math.max(0, lives))}</p>
          </div>
        </div>
      </div>

      <div className="mt-5 rounded-2xl overflow-hidden border border-white/10 bg-black/60" style={{ aspectRatio: "16 / 9" }}>
        <canvas ref={canvasRef} className="w-full h-full block touch-none" />
      </div>

      <div className="mt-5 flex items-center justify-between gap-4">
        <p className="font-mono text-[0.65rem] text-white/50 tracking-[0.25em]">{running ? "FLIGHT · ACTIVE" : over ? "TRANSMISSION · LOST" : "STANDBY"}</p>
        <button className="btn-primary" onClick={start}>{over ? "RESTART MISSION" : running ? "RESET" : "ENGAGE"}</button>
      </div>
    </div>
  );
}

/* ============ Game 2: Crypto Trader Clicker ============ */
const tickers = [
  { sym: "SOL", name: "Solana", base: 160, vol: 0.018, color: "#b794f4" },
  { sym: "BTC", name: "Bitcoin", base: 68000, vol: 0.012, color: "#ffb347" },
  { sym: "NVDA", name: "NVIDIA", base: 118, vol: 0.022, color: "#7ce2ff" },
  { sym: "GOLD", name: "Gold Futures", base: 2680, vol: 0.008, color: "#ffd27a" },
];

function CryptoClicker() {
  const [cash, setCash] = useState(10_000);
  const [portfolio, setPortfolio] = useState<Record<string, number>>(() => Object.fromEntries(tickers.map((t) => [t.sym, 0])));
  const [prices, setPrices] = useState<Record<string, number>>(() => Object.fromEntries(tickers.map((t) => [t.sym, t.base])));
  const [history, setHistory] = useState<Record<string, number[]>>(() => Object.fromEntries(tickers.map((t) => [t.sym, [t.base, t.base, t.base]])));
  const [clicks, setClicks] = useState(0);
  const [best, setBest] = useState(Number(localStorage.getItem("clicker:best") || 0));

  // Price tick
  useEffect(() => {
    const id = setInterval(() => {
      setPrices((prev) => {
        const next: Record<string, number> = { ...prev };
        for (const t of tickers) {
          const drift = (Math.random() - 0.48) * t.vol;
          next[t.sym] = Math.max(1, prev[t.sym] * (1 + drift));
        }
        return next;
      });
      setHistory((h) => {
        const n: Record<string, number[]> = { ...h };
        for (const t of tickers) {
          const arr = [...(h[t.sym] || []), prices[t.sym]];
          if (arr.length > 40) arr.shift();
          n[t.sym] = arr;
        }
        return n;
      });
    }, 700);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prices]);

  const portfolioValue = tickers.reduce((sum, t) => sum + (portfolio[t.sym] || 0) * prices[t.sym], 0);
  const netWorth = cash + portfolioValue;

  useEffect(() => {
    if (netWorth > best) {
      setBest(netWorth);
      localStorage.setItem("clicker:best", String(Math.floor(netWorth)));
    }
  }, [netWorth, best]);

  const click = (sym: string, mode: "buy" | "sell") => {
    const p = prices[sym];
    setClicks((c) => c + 1);
    if (mode === "buy") {
      if (cash < p) return;
      setCash((c) => c - p);
      setPortfolio((pf) => ({ ...pf, [sym]: (pf[sym] || 0) + 1 }));
    } else {
      if ((portfolio[sym] || 0) <= 0) return;
      setCash((c) => c + p);
      setPortfolio((pf) => ({ ...pf, [sym]: pf[sym] - 1 }));
    }
  };

  // Chart mini
  const MiniChart = ({ sym }: { sym: string }) => {
    const data = history[sym] || [];
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const W = 160, H = 44;
    const pts = data.map((v, i) => {
      const x = (i / Math.max(1, data.length - 1)) * W;
      const y = H - ((v - min) / range) * (H - 6) - 3;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ");
    return (
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-10">
        <polyline fill="none" stroke={tickers.find((t) => t.sym === sym)?.color || "#ffb347"} strokeWidth="1.5" points={pts} />
      </svg>
    );
  };

  return (
    <div className="glass rounded-3xl p-6 md:p-8 relative overflow-hidden">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <span className="chip">ARCADE · 02</span>
          <h3 className="font-display text-2xl md:text-3xl text-amber-50 mt-3 font-bold">Crypto Trader · Clicker</h3>
          <p className="text-sm text-white/70 mt-2 max-w-xl font-medium">Tap to buy and sell across a live simulated portfolio. Grow your net worth against a moving market — every click is a decision.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">CASH</p>
            <p className="font-display text-lg text-amber-200">${cash.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          </div>
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">NET</p>
            <p className="font-display text-lg text-amber-200">${netWorth.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          </div>
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">BEST</p>
            <p className="font-display text-lg text-amber-200">${best.toLocaleString()}</p>
          </div>
          <div className="glass rounded-xl px-4 py-2">
            <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">CLICKS</p>
            <p className="font-display text-lg text-amber-200">{clicks}</p>
          </div>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {tickers.map((t) => {
          const p = prices[t.sym];
          const qty = portfolio[t.sym] || 0;
          return (
            <div key={t.sym} className="glass rounded-2xl p-5 relative">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-display text-lg text-amber-50 tracking-widest">{t.sym}</p>
                  <p className="font-mono text-[0.7rem] text-white/50">{t.name}</p>
                </div>
                <div className="text-right">
                  <p className="font-display text-xl" style={{ color: t.color }}>${p.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
                  <p className="font-mono text-[0.65rem] text-white/50">HELD · {qty}</p>
                </div>
              </div>
              <div className="mt-2"><MiniChart sym={t.sym} /></div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  onClick={() => click(t.sym, "buy")}
                  disabled={cash < p}
                  className="btn-primary !py-2 !text-[0.65rem] disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ background: `linear-gradient(135deg, ${t.color}ee, ${t.color}88)`, color: "#120a00" }}
                >
                  BUY · ${p.toFixed(0)}
                </button>
                <button
                  onClick={() => click(t.sym, "sell")}
                  disabled={qty <= 0}
                  className="btn-ghost !py-2 !text-[0.65rem] disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ borderColor: `${t.color}66` }}
                >
                  SELL · ${p.toFixed(0)}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-5 flex items-center justify-between">
        <p className="font-mono text-[0.65rem] text-white/50 tracking-[0.25em]">PORTFOLIO VALUE · ${portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
        <button
          className="btn-ghost !text-[0.7rem]"
          onClick={() => {
            setCash(10000);
            setPortfolio(Object.fromEntries(tickers.map((t) => [t.sym, 0])));
            setClicks(0);
          }}
        >
          LIQUIDATE & RESET
        </button>
      </div>
    </div>
  );
}

export default function Arcade() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="relative z-10 pt-36 pb-24 px-6"
    >
      <div className="mx-auto max-w-7xl">
        <div>
          <p className="font-mono text-[0.7rem] tracking-[0.5em] text-amber-200/70">CHAPTER II · PAGE 03</p>
          <h2 className="font-display text-4xl md:text-6xl text-amber-50 mt-3 glow-text font-bold">The Wormhole Arcade</h2>
          <p className="text-white/70 mt-3 max-w-2xl font-medium">Two mini-games, built in. Play, practice, and collect bragging rights — high scores persist on your device.</p>
        </div>
        <div className="divider-line my-10" />

        <div className="grid grid-cols-1 gap-6">
          <SpaceEvader />
          <CryptoClicker />
        </div>
      </div>
    </motion.section>
  );
}
