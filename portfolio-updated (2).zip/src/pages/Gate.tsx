import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useAudio } from "../components/AudioManager";

export default function Gate() {
  const [warping, setWarping] = useState(false);
  const [pressed, setPressed] = useState(false);
  const navigate = useNavigate();
  const { play } = useAudio();

  const enterUniverse = () => {
    if (warping) return;
    setWarping(true);
    setPressed(true);
    play(); // auto-start ambient score on user gesture
    setTimeout(() => navigate("/overview"), 1500);
  };

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6"
    >
      {/* epigraph */}
      <div className="absolute top-28 md:top-32 left-1/2 -translate-x-1/2 text-center">
        <p className="font-mono text-[0.7rem] tracking-[0.5em] text-white/50">— TRANSMISSION · 001 —</p>
        <p className="font-display text-xs md:text-sm text-amber-100/60 tracking-[0.3em] mt-2">A PORTFOLIO IN ORBIT</p>
      </div>

      {/* title */}
      <div className="text-center mb-10 md:mb-14 mt-10">
        <p className="font-mono text-[0.7rem] tracking-[0.4em] text-amber-200/70">CHAPTER I · THE SPACE GATE</p>
        <h1 className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl mt-5 text-amber-50 glow-text leading-[1.02] font-bold">
          Entering <span className="italic text-amber-200">My</span> Universe
        </h1>
        <div className="mt-6 flex items-center justify-center gap-3 sm:gap-4">
          <span className="h-px w-10 sm:w-20 bg-gradient-to-r from-transparent to-amber-300/50" />
          <span className="font-mono text-[0.6rem] sm:text-[0.65rem] tracking-[0.3em] sm:tracking-[0.4em] text-white/60 font-semibold">SURYANSH · DESIGNER · DEVELOPER · DREAMER</span>
          <span className="h-px w-10 sm:w-20 bg-gradient-to-l from-transparent to-amber-300/50" />
        </div>
        <p className="mt-6 text-sm md:text-base text-white/70 max-w-2xl mx-auto leading-relaxed font-medium">
          Beyond the event horizon lies a constellation of <span className="text-amber-100 font-bold">achievements</span>, <span className="text-amber-100 font-bold">projects</span>, and <span className="text-amber-100 font-bold">curiosities</span>.
          Step through the gate to begin the journey.
        </p>
      </div>

      {/* Gate */}
      <div className="relative flex flex-col items-center">
        <button
          onClick={enterUniverse}
          aria-label="Enter Universe"
          className="group relative outline-none focus-visible:ring-2 focus-visible:ring-amber-300/50 rounded-full"
        >
          <motion.div
            animate={{ scale: pressed ? 1.8 : 1, opacity: pressed ? 0 : 1 }}
            transition={{ duration: 1.4, ease: [0.6, 0.05, 0.3, 1] }}
            className="relative gate-glow"
          >
            {/* SVG stylised gate — inspired by a portal/stargate with luminous inner */}
            <svg viewBox="0 0 400 400" className="w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px] h-auto">
              <defs>
                <radialGradient id="portalCore" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#0b0b15" />
                  <stop offset="55%" stopColor="#0a1024" />
                  <stop offset="85%" stopColor="rgba(120,200,255,0.25)" />
                  <stop offset="100%" stopColor="rgba(180,140,255,0.0)" />
                </radialGradient>
                <radialGradient id="portalHot" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="rgba(255,220,170,0.0)" />
                  <stop offset="85%" stopColor="rgba(255,180,100,0.0)" />
                  <stop offset="100%" stopColor="rgba(255,180,100,0.35)" />
                </radialGradient>
                <linearGradient id="ringMetal" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#4a4254" />
                  <stop offset="45%" stopColor="#8a7a68" />
                  <stop offset="100%" stopColor="#2a2430" />
                </linearGradient>
                <filter id="softGlow">
                  <feGaussianBlur stdDeviation="6" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* ambient hot ring */}
              <circle cx="200" cy="200" r="180" fill="url(#portalHot)" filter="url(#softGlow)" />

              {/* portal core */}
              <circle cx="200" cy="200" r="150" fill="url(#portalCore)" />

              {/* rotating runes */}
              <g transform="translate(200 200)">
                <g style={{ transformOrigin: "0 0", animation: "spin 30s linear infinite" }}>
                  {Array.from({ length: 24 }).map((_, i) => {
                    const a = (i / 24) * Math.PI * 2;
                    const x = Math.cos(a) * 165;
                    const y = Math.sin(a) * 165;
                    return (
                      <rect key={i} x={x - 2} y={y - 10} width="3" height="12" rx="2"
                        fill={i % 3 === 0 ? "#ffd27a" : "#9aa3b2"}
                        opacity="0.75"
                        transform={`rotate(${(a * 180) / Math.PI + 90} ${x} ${y})`} />
                    );
                  })}
                </g>
              </g>

              {/* main ring */}
              <circle cx="200" cy="200" r="160" fill="none" stroke="url(#ringMetal)" strokeWidth="8" />
              <circle cx="200" cy="200" r="156" fill="none" stroke="rgba(255,210,170,0.5)" strokeWidth="1" />
              <circle cx="200" cy="200" r="164" fill="none" stroke="rgba(255,180,100,0.3)" strokeWidth="1" />

              {/* chevrons */}
              {Array.from({ length: 9 }).map((_, i) => {
                const a = (i / 9) * Math.PI * 2;
                const x = 200 + Math.cos(a) * 160;
                const y = 200 + Math.sin(a) * 160;
                return (
                  <g key={i} transform={`translate(${x} ${y}) rotate(${(a * 180) / Math.PI + 90})`}>
                    <polygon points="-10,0 0,-16 10,0 0,16" fill="#1a1520" stroke="#ffd27a" strokeWidth="1.2" />
                  </g>
                );
              })}

              {/* shimmer horizon */}
              <ellipse cx="200" cy="200" rx="140" ry="6" fill="rgba(255,220,170,0.25)" filter="url(#softGlow)" />
            </svg>

            {/* Label on gate */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <p className="font-mono text-[0.7rem] tracking-[0.5em] text-amber-200/80">SYSTEM READY</p>
                <p className="font-display text-xl md:text-2xl text-white mt-2 tracking-[0.2em] group-hover:text-amber-100 transition">
                  ENTER
                </p>
                <p className="font-display text-[0.75rem] text-white/50 tracking-[0.4em] mt-1">UNIVERSE</p>
              </div>
            </div>
          </motion.div>

          {/* hover instruction */}
          <div className="mt-8 text-center">
            <span className="inline-flex items-center gap-3 text-[0.7rem] font-mono tracking-[0.4em] text-white/50 group-hover:text-amber-100/80 transition">
              <span className="h-px w-8 bg-white/30 group-hover:bg-amber-200/60 transition" />
              CLICK THE GATE TO BEGIN
              <span className="h-px w-8 bg-white/30 group-hover:bg-amber-200/60 transition" />
            </span>
          </div>
        </button>
      </div>

      {/* footer coords */}
      <div className="absolute bottom-6 left-0 right-0 text-center">
        <p className="font-mono text-[0.65rem] tracking-[0.4em] text-white/40">
          LAT · 31.3264° N &nbsp;·&nbsp; LON · 75.5762° E &nbsp;·&nbsp; SIGNAL · CLEAR
        </p>
      </div>

      {/* Warp overlay */}
      <div className={`warp-overlay ${warping ? "active" : ""}`} />
    </motion.section>
  );
}
