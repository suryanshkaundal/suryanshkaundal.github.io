import { Link } from "react-router-dom";

const achievements = [
  {
    code: "ACH · 01",
    title: "ISRO YUVIKA 2026",
    org: "Indian Space Research Organisation",
    desc: "Selected among a national cohort for ISRO's Young Scientist Programme — an immersion into satellite engineering, space sciences, and research methodology.",
    tags: ["Space Science", "National", "Research"],
    xp: 950,
    icon: "🛰️",
  },
  {
    code: "ACH · 02",
    title: "UICO · Informatics",
    org: "Unified Council",
    desc: "AIR 93 · Rank 1 in HP & Punjab. Algorithmic thinking and computer science fundamentals under olympiad conditions.",
    tags: ["CS", "National Top 100", "State Rank 1"],
    xp: 820,
    icon: "⚡",
  },
  {
    code: "ACH · 03",
    title: "MTSO · Mathematics",
    org: "Silverzone & Unified",
    desc: "2× Rank 2 Punjab/HP · Rank 1 Jalandhar. Rigorous problem solving across algebra, geometry & combinatorics.",
    tags: ["Mathematics", "State Rank 2", "City Rank 1"],
    xp: 760,
    icon: "📐",
  },
  {
    code: "ACH · 04",
    title: "Abacus · LPU",
    org: "Lovely Professional University",
    desc: "Rank 3 Jalandhar · Rank 4 Punjab. Speed-arithmetic and mental computation under timed tournament conditions.",
    tags: ["Mental Math", "State Rank 4", "City Rank 3"],
    xp: 520,
    icon: "🧮",
  },
  {
    code: "ACH · 05",
    title: "Badminton · State",
    org: "DSJA / Punjab Shuttle",
    desc: "Representing the district across state-level tournament circuits. On-court agility, match IQ, and endurance.",
    tags: ["Racquet Sport", "State Level", "Athletics"],
    xp: 460,
    icon: "🏸",
  },
  {
    code: "ACH · 06",
    title: "Multi-Sport Circuit",
    org: "School & District Meets",
    desc: "Cricket, Football, 100m Sprints (District), Chess — athletic breadth alongside competitive and strategic disciplines.",
    tags: ["Athletics", "District", "Strategy"],
    xp: 380,
    icon: "🏃",
  },
];

const orbits = [
  { label: "Space Science", color: "#ffb347", level: 92, icon: "🛰" },
  { label: "Web Dev", color: "#7ce2ff", level: 88, icon: "⟨/⟩" },
  { label: "Data & Analytics", color: "#b794f4", level: 78, icon: "◈" },
  { label: "Finance & Trading", color: "#ffd27a", level: 72, icon: "📈" },
  { label: "Problem Solving", color: "#ff7a1a", level: 90, icon: "✦" },
  { label: "Sports", color: "#9fe6b0", level: 80, icon: "⚑" },
];

export default function Overview() {
  const totalXP = achievements.reduce((a, b) => a + b.xp, 0);
  const level = Math.floor(Math.sqrt(totalXP / 60));
  const xpToNext = Math.pow(level + 1, 2) * 60;
  const xpPct = Math.round((totalXP / xpToNext) * 100);

  return (
    <section className="relative z-10 pt-36 pb-24 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">

        {/* ── Hero / Profile Card ─────────────────────────────── */}
        <div className="glass rounded-3xl overflow-hidden mb-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-0">
            {/* Photo side */}
            <div className="relative min-h-[280px] sm:min-h-[420px]">
              <img
                src="/suryansh.jpg"
                alt="Suryansh — portrait"
                className="absolute inset-0 w-full h-full object-contain object-center"
              />
              {/* gradient fade into card */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-black/80 hidden sm:block" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent sm:hidden" />
            </div>

            {/* Info side */}
            <div className="flex flex-col justify-center px-7 py-8 sm:py-10">
              <p className="font-mono text-[0.65rem] tracking-[0.5em] text-amber-200/70">CHAPTER II · PAGE 01</p>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-amber-50 mt-3 glow-text leading-tight font-bold">
                Suryansh Kaundal
              </h2>
              <p className="font-mono text-[0.72rem] tracking-[0.35em] text-amber-300/80 mt-2">
                DESIGNER · DEVELOPER · EXPLORER
              </p>
              <p className="text-sm sm:text-[0.95rem] text-white/70 mt-5 leading-relaxed font-medium">
                A young scientist, developer, and multi-sport athlete from Jalandhar —
                orbiting between <span className="text-amber-100 font-semibold">space research</span>,{" "}
                <span className="text-amber-100 font-semibold">olympiad competition</span>, and{" "}
                <span className="text-amber-100 font-semibold">building real products</span> on the web.
              </p>

              {/* XP stats row */}
              <div className="mt-7 grid grid-cols-2 gap-3">
                <div className="glass rounded-2xl px-4 py-3">
                  <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">TOTAL XP</p>
                  <p className="font-display text-2xl sm:text-3xl text-amber-200 font-bold">{totalXP.toLocaleString()}</p>
                </div>
                <div className="glass rounded-2xl px-4 py-3">
                  <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">LEVEL</p>
                  <p className="font-display text-2xl sm:text-3xl text-amber-200 font-bold">{level}</p>
                </div>
              </div>

              {/* Level XP bar */}
              <div className="mt-4">
                <div className="flex justify-between mb-2">
                  <span className="font-mono text-[0.62rem] tracking-[0.3em] text-white/50">XP TO LVL {level + 1}</span>
                  <span className="font-mono text-[0.62rem] text-amber-200/80">{xpPct}%</span>
                </div>
                <div className="xp-track h-2.5">
                  <div className="xp-fill" style={{ width: `${xpPct}%` }} />
                </div>
              </div>

              <div className="mt-6 flex flex-wrap gap-2">
                {["ISRO YUVIKA", "AIR 93 · UICO", "State Badminton", "4× Olympiads"].map((t) => (
                  <span key={t} className="chip !text-[0.64rem] font-semibold">{t}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Section label ─────────────────────────────────── */}
        <div className="flex items-center justify-between flex-wrap gap-4 mb-7">
          <div>
            <p className="font-mono text-[0.65rem] tracking-[0.5em] text-amber-200/70">MODULE · A</p>
            <h3 className="font-display text-2xl sm:text-3xl text-amber-50 mt-2 font-bold">Achievements Log</h3>
          </div>
          <Link to="/gadgets" className="btn-ghost !text-[0.7rem] font-semibold">OPEN XP TRACKER →</Link>
        </div>

        {/* ── Achievement Grid ── */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5">
          {achievements.map((a) => (
            <article
              key={a.code}
              className="glass rounded-2xl p-4 sm:p-6 relative overflow-hidden flex flex-col"
            >
              <div className="flex items-start justify-between gap-2">
                <span className="chip !text-[0.6rem] sm:!text-[0.65rem]">{a.code}</span>
                <span className="text-xl sm:text-2xl">{a.icon}</span>
              </div>

              <h4 className="font-display text-base sm:text-xl mt-3 text-amber-50 leading-snug font-bold">{a.title}</h4>
              <p className="font-mono text-[0.62rem] sm:text-[0.7rem] tracking-[0.2em] text-amber-200/70 mt-1">{a.org}</p>
              <p className="text-xs sm:text-sm text-white/70 mt-3 leading-relaxed font-medium flex-1">{a.desc}</p>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {a.tags.map((t) => (
                  <span key={t} className="chip !text-[0.58rem] sm:!text-[0.62rem] font-medium">{t}</span>
                ))}
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="w-20 sm:w-32 xp-track h-1.5 sm:h-2">
                  <div className="xp-fill" style={{ width: `${Math.min(100, (a.xp / 1000) * 100)}%` }} />
                </div>
                <span className="font-mono text-[0.68rem] sm:text-[0.75rem] text-amber-200 font-bold">+{a.xp} XP</span>
              </div>
            </article>
          ))}
        </div>

        <div className="divider-line my-12 sm:my-16" />

        {/* ── Skills Section ─────────────────────────────────── */}
        <div>
          <p className="font-mono text-[0.65rem] tracking-[0.5em] text-amber-200/70">MODULE · B</p>
          <h3 className="font-display text-2xl sm:text-3xl text-amber-50 mt-2 mb-6 font-bold">Skills Orbits</h3>
          <p className="text-white/65 max-w-2xl mb-8 font-medium">
            Each orbit represents a domain of active practice — from engineering the web, to reading financial charts,
            to the pure pattern-craft of competitive problem solving.
          </p>

          {/* Always 2-col grid, 3-col on lg */}
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {orbits.map((o) => (
              <div
                key={o.label}
                className="glass rounded-2xl p-4 sm:p-5 orbit-node"
                style={{ borderColor: `${o.color}33` }}
              >
                <div className="flex items-center gap-2 sm:gap-3 mb-3">
                  <span
                    className="h-9 w-9 sm:h-10 sm:w-10 flex-shrink-0 rounded-xl flex items-center justify-center text-base sm:text-lg font-bold"
                    style={{ background: `${o.color}18`, border: `1px solid ${o.color}55`, color: o.color }}
                  >
                    {o.icon}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[0.7rem] sm:text-[0.78rem] font-bold tracking-[0.15em] uppercase leading-tight" style={{ color: o.color }}>
                      {o.label}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.6rem] text-white/50 tracking-[0.2em]">PROFICIENCY</span>
                  <span className="font-mono text-[0.72rem] font-bold" style={{ color: o.color }}>{o.level}%</span>
                </div>
                <div className="xp-track h-2">
                  <div className="xp-fill" style={{ width: `${o.level}%`, background: o.color, boxShadow: `0 0 14px ${o.color}88` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
