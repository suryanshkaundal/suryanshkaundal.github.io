import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

type Category = "study" | "olympiad" | "sports" | "projects";

type Entry = {
  id: string;
  category: Category;
  label: string;
  level: "Class" | "School" | "City" | "District" | "State" | "National" | "International";
  result: "Participation" | "Top 25%" | "Top 10%" | "Rank 5-10" | "Rank 3" | "Rank 2" | "Rank 1" | "Winner" | "Selected";
  xp: number;
  date: string;
};

const CATEGORY_META: Record<Category, { label: string; color: string; icon: string; desc: string }> = {
  study: { label: "Study & Academics", color: "#7ce2ff", icon: "◇", desc: "Curricular hours, examinations, and personal learning." },
  olympiad: { label: "Olympiads & Competitions", color: "#ffb347", icon: "◈", desc: "STEM olympiads, informatics, mathematics, language." },
  sports: { label: "Sports & Athletics", color: "#9fe6b0", icon: "⚑", desc: "Tournaments, sprints, racquet sports, team games." },
  projects: { label: "Projects & Builds", color: "#b794f4", icon: "✦", desc: "Websites, apps, experiments, and ongoing work." },
};

const LEVEL_XP: Record<Entry["level"], number> = {
  Class: 20,
  School: 40,
  City: 70,
  District: 100,
  State: 160,
  National: 240,
  International: 360,
};
const RESULT_MULT: Record<Entry["result"], number> = {
  Participation: 1,
  "Top 25%": 1.5,
  "Top 10%": 2,
  "Rank 5-10": 2.5,
  "Rank 3": 3.2,
  "Rank 2": 3.6,
  "Rank 1": 4.2,
  Winner: 4.5,
  Selected: 5,
};

const seedEntries = (): Entry[] => [
  { id: "s1", category: "olympiad", label: "ISRO YUVIKA 2026", level: "National", result: "Selected", xp: Math.round(LEVEL_XP.National * RESULT_MULT.Selected), date: "2026-04" },
  { id: "s2", category: "olympiad", label: "UICO · AIR 93", level: "National", result: "Rank 1", xp: Math.round(LEVEL_XP.National * RESULT_MULT["Rank 1"]), date: "2025-11" },
  { id: "s3", category: "olympiad", label: "MTSO · State Rank 2", level: "State", result: "Rank 2", xp: Math.round(LEVEL_XP.State * RESULT_MULT["Rank 2"]), date: "2025-10" },
  { id: "s4", category: "olympiad", label: "Abacus Championship · Rank 4", level: "State", result: "Rank 3", xp: Math.round(LEVEL_XP.State * RESULT_MULT["Rank 3"]), date: "2025-08" },
  { id: "s5", category: "sports", label: "Badminton · State Circuit", level: "State", result: "Top 10%", xp: Math.round(LEVEL_XP.State * RESULT_MULT["Top 10%"]), date: "2025-07" },
  { id: "s6", category: "sports", label: "100m Sprints · District", level: "District", result: "Top 10%", xp: Math.round(LEVEL_XP.District * RESULT_MULT["Top 10%"]), date: "2025-05" },
  { id: "s7", category: "projects", label: "TechKindness — Launch", level: "National", result: "Winner", xp: Math.round(LEVEL_XP.National * RESULT_MULT.Winner * 0.6), date: "2026-01" },
  { id: "s8", category: "projects", label: "Study DarkForge", level: "State", result: "Winner", xp: Math.round(LEVEL_XP.State * RESULT_MULT.Winner), date: "2025-12" },
  { id: "s9", category: "study", label: "Class 10 · Mid Term", level: "Class", result: "Top 10%", xp: Math.round(LEVEL_XP.Class * RESULT_MULT["Top 10%"] * 2), date: "2025-09" },
];

const STORAGE_KEY = "xp:entries:v1";

export default function Gadgets() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [form, setForm] = useState<{ category: Category; label: string; level: Entry["level"]; result: Entry["result"]; overrideXP: string }>({
    category: "olympiad",
    label: "",
    level: "School",
    result: "Participation",
    overrideXP: "",
  });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        setEntries(JSON.parse(raw));
      } else {
        setEntries(seedEntries());
      }
    } catch {
      setEntries(seedEntries());
    }
  }, []);

  useEffect(() => {
    if (entries.length) localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  }, [entries]);

  const totals = useMemo(() => {
    const per: Record<Category, number> = { study: 0, olympiad: 0, sports: 0, projects: 0 };
    for (const e of entries) per[e.category] += e.xp;
    const total = Object.values(per).reduce((a, b) => a + b, 0);
    const level = Math.floor(Math.sqrt(total / 40));
    return { per, total, level };
  }, [entries]);

  const previewXP = useMemo(() => {
    if (form.overrideXP && !isNaN(Number(form.overrideXP))) return Number(form.overrideXP);
    return Math.round(LEVEL_XP[form.level] * RESULT_MULT[form.result]);
  }, [form]);

  const addEntry = () => {
    if (!form.label.trim()) return;
    const e: Entry = {
      id: "u" + Math.random().toString(36).slice(2, 8),
      category: form.category,
      label: form.label.trim(),
      level: form.level,
      result: form.result,
      xp: previewXP,
      date: new Date().toISOString().slice(0, 7),
    };
    setEntries((prev) => [e, ...prev]);
    setForm((f) => ({ ...f, label: "", overrideXP: "" }));
  };

  const remove = (id: string) => setEntries((prev) => prev.filter((e) => e.id !== id));
  const reset = () => {
    if (confirm("Reset the XP ledger to defaults?")) setEntries(seedEntries());
  };

  const catOrder: Category[] = ["study", "olympiad", "sports", "projects"];
  const maxCat = Math.max(...Object.values(totals.per), 1);

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="relative z-10 pt-36 pb-24 px-6"
    >
      <div className="mx-auto max-w-7xl">
        <div className="flex items-end justify-between gap-6 flex-wrap">
          <div>
            <p className="font-mono text-[0.7rem] tracking-[0.5em] text-amber-200/70">CHAPTER II · PAGE 04</p>
          <h2 className="font-display text-4xl md:text-6xl text-amber-50 mt-3 glow-text font-bold">Mini Gadgets</h2>
          <p className="text-white/70 mt-3 max-w-2xl font-medium">Lightweight tools running inside the universe. XP Ledger is live — more gadgets under construction.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="glass rounded-2xl px-5 py-3">
              <p className="font-mono text-[0.65rem] tracking-[0.3em] text-white/50">LEVEL</p>
              <p className="font-display text-3xl text-amber-200">{totals.level}</p>
            </div>
            <div className="glass rounded-2xl px-5 py-3">
              <p className="font-mono text-[0.65rem] tracking-[0.3em] text-white/50">TOTAL XP</p>
              <p className="font-display text-3xl text-amber-200">{totals.total.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="divider-line my-10" />

        {/* XP Ledger header card */}
        <div className="glass rounded-3xl p-6 md:p-8 mb-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <span className="chip">GADGET · 01 · LIVE</span>
          <h3 className="font-display text-2xl md:text-3xl text-amber-50 mt-3 font-bold">XP Ledger</h3>
          <p className="text-sm text-white/70 mt-2 max-w-2xl font-medium">
                Distributed across four domains. Each entry earns XP based on its <span className="text-amber-100">competitive level</span> and <span className="text-amber-100">result</span>. You can override the suggested value.
              </p>
            </div>
            <button className="btn-ghost !text-[0.7rem]" onClick={reset}>RESET TO DEFAULTS</button>
          </div>

          {/* Category bars */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            {catOrder.map((c) => {
              const meta = CATEGORY_META[c];
              const val = totals.per[c];
              const pct = Math.max(4, (val / maxCat) * 100);
              return (
                <div key={c} className="glass rounded-2xl p-5" style={{ borderColor: `${meta.color}33` }}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="h-9 w-9 rounded-xl flex items-center justify-center text-lg" style={{ background: `${meta.color}22`, color: meta.color, border: `1px solid ${meta.color}55` }}>{meta.icon}</span>
                      <div>
                        <p className="font-display text-base text-amber-50 tracking-widest">{meta.label}</p>
                        <p className="font-mono text-[0.65rem] text-white/50 tracking-[0.2em]">{meta.desc}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-display text-xl" style={{ color: meta.color }}>{val.toLocaleString()}</p>
                      <p className="font-mono text-[0.6rem] text-white/50">XP</p>
                    </div>
                  </div>
                  <div className="mt-4 xp-track h-2">
                    <div className="xp-fill" style={{ width: `${pct}%`, background: meta.color, boxShadow: `0 0 18px ${meta.color}99` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Entry form */}
        <div className="glass rounded-3xl p-6 md:p-8 mb-6">
          <h3 className="font-display text-xl text-amber-50">Log a new entry</h3>
          <p className="text-sm text-white/60 mt-1">Describe the milestone, pick the level and your result — suggested XP computes automatically.</p>

          <div className="mt-5 grid grid-cols-1 md:grid-cols-6 gap-3">
            <div className="md:col-span-2">
              <label className="font-mono text-[0.65rem] tracking-[0.25em] text-white/50">CATEGORY</label>
              <select
                className="mt-1 w-full bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-amber-50 focus:border-amber-300/50 outline-none"
                value={form.category}
                onChange={(e) => setForm((f) => ({ ...f, category: e.target.value as Category }))}
              >
                {catOrder.map((c) => (
                  <option key={c} value={c} style={{ background: "#111" }}>{CATEGORY_META[c].label}</option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="font-mono text-[0.65rem] tracking-[0.25em] text-white/50">LABEL</label>
              <input
                className="mt-1 w-full bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-amber-50 focus:border-amber-300/50 outline-none placeholder:text-white/30"
                placeholder="e.g. Badminton — City Open 2026"
                value={form.label}
                onChange={(e) => setForm((f) => ({ ...f, label: e.target.value }))}
              />
            </div>

            <div>
              <label className="font-mono text-[0.65rem] tracking-[0.25em] text-white/50">LEVEL</label>
              <select
                className="mt-1 w-full bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-amber-50 focus:border-amber-300/50 outline-none"
                value={form.level}
                onChange={(e) => setForm((f) => ({ ...f, level: e.target.value as Entry["level"] }))}
              >
                {(Object.keys(LEVEL_XP) as Entry["level"][]).map((k) => (
                  <option key={k} value={k} style={{ background: "#111" }}>{k}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-mono text-[0.65rem] tracking-[0.25em] text-white/50">RESULT</label>
              <select
                className="mt-1 w-full bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-amber-50 focus:border-amber-300/50 outline-none"
                value={form.result}
                onChange={(e) => setForm((f) => ({ ...f, result: e.target.value as Entry["result"] }))}
              >
                {(Object.keys(RESULT_MULT) as Entry["result"][]).map((k) => (
                  <option key={k} value={k} style={{ background: "#111" }}>{k}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-4 flex items-end justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-4 flex-wrap">
              <div>
                <label className="font-mono text-[0.65rem] tracking-[0.25em] text-white/50">OVERRIDE XP (OPTIONAL)</label>
                <input
                  className="mt-1 w-36 bg-white/[0.04] border border-white/10 rounded-xl px-3 py-2 text-sm text-amber-50 focus:border-amber-300/50 outline-none"
                  placeholder={String(previewXP)}
                  value={form.overrideXP}
                  onChange={(e) => setForm((f) => ({ ...f, overrideXP: e.target.value }))}
                />
              </div>
              <div className="glass rounded-xl px-4 py-3">
                <p className="font-mono text-[0.6rem] tracking-[0.3em] text-white/50">SUGGESTED</p>
                <p className="font-display text-2xl text-amber-200">+{previewXP} XP</p>
              </div>
            </div>
            <button className="btn-primary" onClick={addEntry}>LOG ENTRY →</button>
          </div>
        </div>

        {/* Entries table */}
        <div className="glass rounded-3xl p-6 md:p-8">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-xl text-amber-50">Ledger · {entries.length} entries</h3>
            <p className="font-mono text-[0.65rem] text-white/50 tracking-[0.3em]">SAVED LOCALLY</p>
          </div>
          <div className="mt-5 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="font-mono text-[0.65rem] tracking-[0.3em] text-white/50">
                  <th className="py-2 pr-4">DATE</th>
                  <th className="py-2 pr-4">CATEGORY</th>
                  <th className="py-2 pr-4">MILESTONE</th>
                  <th className="py-2 pr-4">LEVEL</th>
                  <th className="py-2 pr-4">RESULT</th>
                  <th className="py-2 pr-4 text-right">XP</th>
                  <th className="py-2 pr-2" />
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => {
                  const meta = CATEGORY_META[e.category];
                  return (
                    <tr key={e.id} className="border-t border-white/5 hover:bg-white/[0.025] transition">
                      <td className="py-3 pr-4 font-mono text-[0.7rem] text-white/60">{e.date}</td>
                      <td className="py-3 pr-4">
                        <span className="chip" style={{ color: meta.color, borderColor: `${meta.color}55` }}>{meta.label}</span>
                      </td>
                      <td className="py-3 pr-4 text-amber-50">{e.label}</td>
                      <td className="py-3 pr-4 font-mono text-[0.75rem] text-white/70">{e.level}</td>
                      <td className="py-3 pr-4 font-mono text-[0.75rem] text-white/70">{e.result}</td>
                      <td className="py-3 pr-4 text-right font-display text-amber-200">+{e.xp}</td>
                      <td className="py-3 pr-2 text-right">
                        <button className="text-white/40 hover:text-red-300 text-xs tracking-widest" onClick={() => remove(e.id)}>REMOVE</button>
                      </td>
                    </tr>
                  );
                })}
                {entries.length === 0 && (
                  <tr><td colSpan={7} className="py-6 text-white/40 text-center font-mono text-[0.7rem] tracking-[0.2em]">LEDGER EMPTY</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Upcoming gadgets */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            { t: "Focus Timer", d: "Pomodoro-style session tracker with ambient loops.", i: "◷" },
            { t: "Syllabus Mapper", d: "Chapter-by-chapter coverage graph with checkpoint XP.", i: "▣" },
            { t: "Finance Journal", d: "Log allowance, savings, and simulated positions.", i: "⌬" },
          ].map((g) => (
            <div key={g.t} className="glass rounded-2xl p-5 opacity-80">
              <div className="flex items-center justify-between">
                <span className="h-9 w-9 rounded-xl flex items-center justify-center text-lg bg-white/[0.03] border border-white/10 text-amber-100">{g.i}</span>
                <span className="chip">UPCOMING</span>
              </div>
              <h4 className="font-display text-lg text-amber-50 mt-4">{g.t}</h4>
              <p className="text-sm text-white/60 mt-1">{g.d}</p>
              <div className="mt-4 h-1.5 xp-track"><div className="xp-fill" style={{ width: "20%", background: "rgba(255,255,255,0.3)", boxShadow: "none" }} /></div>
            </div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}
